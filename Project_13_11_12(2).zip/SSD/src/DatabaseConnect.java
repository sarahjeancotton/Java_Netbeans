/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author NSS
 */
import java.sql.*;
import javax.swing.*;
public class DatabaseConnect {
Connection conn = null;
ResultSet rs = null;
PreparedStatement pst = null;
public static Connection ConnectDB(){
    try{
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Localuser\\Desktop\\SSD\\database.sqlite");
   //     JOptionPane.showMessageDialog(null, "Connection Established");
        return conn;

    }catch(Exception e){
        JOptionPane.showMessageDialog(null, e);
        return null;
    }
}
}
